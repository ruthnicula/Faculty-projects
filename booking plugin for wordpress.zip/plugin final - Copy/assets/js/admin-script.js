jQuery(document).ready(function($) {
    $("#accordion").accordion();
});
