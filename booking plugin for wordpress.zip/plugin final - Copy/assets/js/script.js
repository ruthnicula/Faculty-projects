jQuery(document).ready(function($) {
    var unavailableTimes = [];

    function loadUnavailableTimes(date) {
        var data = {
            action: 'my_booking_get_unavailable_times',
            date: date
        };

        $.post(my_booking_ajax.ajax_url, data, function(response) {
            if (response.success) {
                unavailableTimes = response.data;
                updateTimes();
            }
        });
    }

    function updateTimes() {
        $('#appointment_time option').each(function() {
            var time = $(this).val();
            if (unavailableTimes.includes(time)) {
                $(this).css('color', 'red');
                $(this).data('unavailable', true);
            } else {
                $(this).css('color', 'black');
                $(this).data('unavailable', false);
            }
        });
    }

    $('#calendar').datepicker({
        dateFormat: 'yy-mm-dd',
        minDate: 0,
        onSelect: function(dateText) {
            $('#appointment_date').val(dateText);
            loadUnavailableTimes(dateText);
        }
    });

    $('#appointment_time').on('change', function() {
        var selectedTime = $(this).val();
        if ($(this).find('option:selected').data('unavailable')) {
            alert('An appointment already exists at this time. Please choose another time.');
            $(this).val('');
        }
    });

    $('#bookingForm').on('submit', function(e) {
        e.preventDefault();

        var email = $('#customer_email').val();
        if (!validateEmail(email)) {
            $('#email-error').show();
            return;
        } else {
            $('#email-error').hide();
        }

        var data = {
            action: 'my_booking_save_appointment',
            customer_first_name: $('#customer_first_name').val(),
            customer_last_name: $('#customer_last_name').val(),
            customer_email: email,
            service: $('#service').val(),
            employee: $('#employee').val(),
            appointment_date: $('#appointment_date').val(),
            appointment_time: $('#appointment_time').val(),
        };

        $.post(my_booking_ajax.ajax_url, data, function(response) {
            if (response.success) {
                alert('Appointment booked successfully!');
                $('#bookingForm')[0].reset();
                $('#appointment_time').val('');
                unavailableTimes = [];
            } else {
                alert(response.data.message);
            }
        });
    });

    function validateEmail(email) {
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
});
