<?php
/**
 * Plugin Name: My Booking Plugin
 * Description: Un plugin de rezervări pentru WordPress.
 * Version: 1.0
 * Author: Ruth Nicula
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define constants
define('MY_BOOKING_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MY_BOOKING_PLUGIN_URL', plugin_dir_url(__FILE__));

// Activation hook
register_activation_hook(__FILE__, 'my_booking_plugin_activate');
function my_booking_plugin_activate() {
    my_booking_create_tables();
}

function my_booking_create_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    $tables = [
        "CREATE TABLE {$wpdb->prefix}my_booking_services (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            duration int NOT NULL,
            price float NOT NULL,
            category varchar(255) DEFAULT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;",
        
        "CREATE TABLE {$wpdb->prefix}my_booking_employees (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            first_name varchar(255) NOT NULL,
            last_name varchar(255) NOT NULL,
            email varchar(255) NOT NULL,
            department varchar(255) DEFAULT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;",
        
        "CREATE TABLE {$wpdb->prefix}my_booking_customers (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            first_name varchar(255) NOT NULL,
            last_name varchar(255) NOT NULL,
            email varchar(255) NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;",
        
        "CREATE TABLE {$wpdb->prefix}my_booking_appointments (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            service_id mediumint(9) NOT NULL,
            employee_id mediumint(9) NOT NULL,
            customer_id mediumint(9) NOT NULL,
            appointment_time datetime NOT NULL,
            status varchar(50) DEFAULT 'pending',
            PRIMARY KEY (id),
            FOREIGN KEY (service_id) REFERENCES {$wpdb->prefix}my_booking_services(id) ON DELETE CASCADE,
            FOREIGN KEY (employee_id) REFERENCES {$wpdb->prefix}my_booking_employees(id) ON DELETE CASCADE,
            FOREIGN KEY (customer_id) REFERENCES {$wpdb->prefix}my_booking_customers(id) ON DELETE CASCADE
        ) $charset_collate;"
    ];

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    foreach ($tables as $sql) {
        dbDelta($sql);
    }
}

// Enqueue scripts and styles only on plugin pages
add_action('admin_enqueue_scripts', 'my_booking_plugin_admin_enqueue_scripts');
function my_booking_plugin_admin_enqueue_scripts($hook_suffix) {
    // Check if the current page belongs to the plugin
    if (strpos($hook_suffix, 'my-booking-plugin') !== false) {
        wp_enqueue_style('my-booking-admin-style', MY_BOOKING_PLUGIN_URL . 'assets/css/admin-style.css');
        wp_enqueue_script('jquery-ui-accordion');
        wp_enqueue_script('my-booking-admin-script', MY_BOOKING_PLUGIN_URL . 'assets/js/admin-script.js', array('jquery'), null, true);
    }
}

// Enqueue frontend scripts and styles only on pages where the shortcode is used
add_action('wp_enqueue_scripts', 'my_booking_plugin_enqueue_scripts');
function my_booking_plugin_enqueue_scripts() {
    if (is_page() && has_shortcode(get_post()->post_content, 'my_booking_form')) {
        wp_enqueue_style('my-booking-style', MY_BOOKING_PLUGIN_URL . 'assets/css/style.css');
        wp_enqueue_style('jquery-ui-datepicker-style', '//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_script('my-booking-script', MY_BOOKING_PLUGIN_URL . 'assets/js/script.js', array('jquery', 'jquery-ui-datepicker'), null, true);
        wp_localize_script('my-booking-script', 'my_booking_ajax', array('ajax_url' => admin_url('admin-ajax.php')));
    }
}

// Admin menu
add_action('admin_menu', 'my_booking_plugin_admin_menu');
function my_booking_plugin_admin_menu() {
    add_menu_page('My Booking Plugin', 'Booking Plugin', 'manage_options', 'my-booking-plugin', 'my_booking_dashboard_page', 'dashicons-calendar-alt');
    add_submenu_page('my-booking-plugin', 'Dashboard', 'Dashboard', 'manage_options', 'my-booking-dashboard', 'my_booking_dashboard_page');
    add_submenu_page('my-booking-plugin', 'Services', 'Services', 'manage_options', 'my-booking-services', 'my_booking_services_page');
    add_submenu_page('my-booking-plugin', 'Employees', 'Employees', 'manage_options', 'my-booking-employees', 'my_booking_employees_page');
    add_submenu_page('my-booking-plugin', 'Customers', 'Customers', 'manage_options', 'my-booking-customers', 'my_booking_customers_page');
    add_submenu_page('my-booking-plugin', 'Appointments', 'Appointments', 'manage_options', 'my-booking-appointments', 'my_booking_appointments_page');
    add_submenu_page('my-booking-plugin', 'Notifications', 'Notifications', 'manage_options', 'my-booking-notifications', 'my_booking_notifications_page');
    add_submenu_page('my-booking-plugin', 'Settings', 'Settings', 'manage_options', 'my-booking-settings', 'my_booking_settings_page');
}

function my_booking_dashboard_page() {
    global $wpdb;

    // Obține programările aprobate
    $approved_appointments = $wpdb->get_results("SELECT a.*, s.name as service_name, e.department as employee_department, c.first_name as customer_first_name, c.last_name as customer_last_name FROM {$wpdb->prefix}my_booking_appointments a JOIN {$wpdb->prefix}my_booking_services s ON a.service_id = s.id JOIN {$wpdb->prefix}my_booking_employees e ON a.employee_id = e.id JOIN {$wpdb->prefix}my_booking_customers c ON a.customer_id = c.id WHERE a.status = 'approved'");
    
    // Obține programările viitoare
    $upcoming_appointments = $wpdb->get_results("SELECT a.*, s.name as service_name, e.department as employee_department, c.first_name as customer_first_name, c.last_name as customer_last_name FROM {$wpdb->prefix}my_booking_appointments a JOIN {$wpdb->prefix}my_booking_services s ON a.service_id = s.id JOIN {$wpdb->prefix}my_booking_employees e ON a.employee_id = e.id JOIN {$wpdb->prefix}my_booking_customers c ON a.customer_id = c.id WHERE a.appointment_time >= NOW()");

    // Calculează numărul de programări aprobate
    $approved_count = count($approved_appointments);

    // Calculează numărul de programări viitoare
    $upcoming_count = count($upcoming_appointments);

    echo '<div class="wrap my-booking-plugin"><h1>Dashboard</h1>';

    // Afișează programările aprobate
    echo '<h2>Approved Appointments (' . esc_html($approved_count) . ')</h2><ul>';
    foreach ($approved_appointments as $appointment) {
        echo '<li>' . esc_html($appointment->appointment_time) . ' - ' . esc_html($appointment->customer_first_name . ' ' . $appointment->customer_last_name) . ' - ' . esc_html($appointment->service_name) . ' - ' . esc_html($appointment->employee_department) . '</li>';
    }
    echo '</ul>';

    // Afișează programările viitoare
    echo '<h2>Upcoming Appointments (' . esc_html($upcoming_count) . ')</h2><ul>';
    foreach ($upcoming_appointments as $appointment) {
        echo '<li>' . esc_html($appointment->appointment_time) . ' - ' . esc_html($appointment->customer_first_name . ' ' . $appointment->customer_last_name) . ' - ' . esc_html($appointment->service_name) . ' - ' . esc_html($appointment->employee_department) . '</li>';
    }
    echo '</ul>';

    echo '</div>';

    echo '<style>
    .wrap.my-booking-plugin {
        width: 100%;
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ddd;
        border-radius: 20px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        background-color: #fff;
    }

    .wrap.my-booking-plugin h1 {
        font-size: 24px;
        margin-bottom: 20px;
        color: #0EBADC;
    }

    .wrap.my-booking-plugin h2 {
        font-size: 20px;
        margin-bottom: 10px;
        color: #333;
    }

    .wrap.my-booking-plugin label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
        color: #555;
    }

    .wrap.my-booking-plugin input[type="text"],
    .wrap.my-booking-plugin input[type="email"],
    .wrap.my-booking-plugin input[type="datetime-local"],
    .wrap.my-booking-plugin input[type="number"],
    .wrap.my-booking-plugin select {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
    }

    .wrap.my-booking-plugin input[type="submit"],
    .wrap.my-booking-plugin button {
        background-color: #0EBADC;
        color: #fff;
        border: none;
        padding: 10px 20px;
        cursor: pointer;
        border-radius: 5px;
        font-size: 16px;
        margin-right: 10px;
    }

    .wrap.my-booking-plugin input[type="submit"]:hover,
    .wrap.my-booking-plugin button:hover {
        background-color: #0c9ab0;
    }

    .wrap.my-booking-plugin form {
        margin-bottom: 20px;
    }

    .wrap.my-booking-plugin ul {
        list-style: none;
        padding: 0;
    }

    .wrap.my-booking-plugin ul li {
        padding: 10px;
        border-bottom: 1px solid #ddd;
    }

    #modifyServiceModal,
    #modifyEmployeeModal,
    #modifyCustomerModal,
    #modifyAppointmentModal,
    #updateStatusModal {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        padding: 20px;
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        z-index: 1000;
    }

    #modifyServiceModal h2,
    #modifyEmployeeModal h2,
    #modifyCustomerModal h2,
    #modifyAppointmentModal h2,
    #updateStatusModal h2 {
        margin-top: 0;
    }
</style>';

}



function my_booking_services_page() {
    global $wpdb;

    // Handle new service addition
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_service'])) {
        $wpdb->insert(
            "{$wpdb->prefix}my_booking_services",
            array(
                'name' => sanitize_text_field($_POST['service_name']),
                'duration' => intval($_POST['service_duration']),
                'price' => floatval($_POST['service_price']),
                'category' => sanitize_text_field($_POST['service_category'])
            )
        );
    }

    // Handle service deletion
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_service'])) {
        $service_id = intval($_POST['service_id']);
        $wpdb->delete("{$wpdb->prefix}my_booking_services", array('id' => $service_id));
    }

    // Handle service modification
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['modify_service'])) {
        $service_id = intval($_POST['service_id']);
        $wpdb->update(
            "{$wpdb->prefix}my_booking_services",
            array(
                'name' => sanitize_text_field($_POST['service_name']),
                'duration' => intval($_POST['service_duration']),
                'price' => floatval($_POST['service_price']),
                'category' => sanitize_text_field($_POST['service_category'])
            ),
            array('id' => $service_id)
        );
    }

    $services = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}my_booking_services");

    echo '<div class="wrap my-booking-plugin"><h1>Services</h1>';
    echo '<form method="POST"><h2>Add New Service</h2>';
    echo '<label>Name</label><input type="text" name="service_name" required>';
    echo '<label>Duration (minutes)</label><input type="number" name="service_duration" required>';
    echo '<label>Price</label><input type="number" step="0.01" name="service_price" required>';
    echo '<label>Category</label><input type="text" name="service_category">';
    echo '<input type="submit" name="new_service" value="Add Service"></form>';

    echo '<h2>Existing Services</h2><ul>';
    foreach ($services as $service) {
        echo '<li>';
        echo esc_html($service->name) . ' - ' . esc_html($service->duration) . ' mins - $' . esc_html($service->price) . ' - ' . esc_html($service->category);
        echo ' <form method="POST" style="display:inline;"><input type="hidden" name="service_id" value="' . esc_attr($service->id) . '">';
        echo '<input type="submit" name="delete_service" value="Delete" onclick="return confirm(\'Are you sure you want to delete this service?\');"></form>';
        echo ' <button onclick="modifyService(' . esc_attr($service->id) . ', \'' . esc_js($service->name) . '\', ' . esc_attr($service->duration) . ', ' . esc_attr($service->price) . ', \'' . esc_js($service->category) . '\')">Modify</button>';
        echo '</li>';
    }
    echo '</ul></div>';

    // Modal for modifying service
    echo '<div id="modifyServiceModal" style="display:none;">';
    echo '<form method="POST"><h2>Modify Service</h2>';
    echo '<input type="hidden" name="service_id" id="modify_service_id">';
    echo '<label>Name</label><input type="text" name="service_name" id="modify_service_name" required>';
    echo '<label>Duration (minutes)</label><input type="number" name="service_duration" id="modify_service_duration" required>';
    echo '<label>Price</label><input type="number" step="0.01" name="service_price" id="modify_service_price" required>';
    echo '<label>Category</label><input type="text" name="service_category" id="modify_service_category">';
    echo '<input type="submit" name="modify_service" value="Modify Service">';
    echo '</form></div>';

    ?>
    <script>
    function modifyService(id, name, duration, price, category) {
        document.getElementById('modify_service_id').value = id;
        document.getElementById('modify_service_name').value = name;
        document.getElementById('modify_service_duration').value = duration;
        document.getElementById('modify_service_price').value = price;
        document.getElementById('modify_service_category').value = category;
        document.getElementById('modifyServiceModal').style.display = 'block';
    }
    </script>
    <?php

echo '<style>
.wrap.my-booking-plugin {
    width: 100%;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    background-color: #fff;
}

.wrap.my-booking-plugin h1 {
    font-size: 24px;
    margin-bottom: 20px;
    color: #0EBADC;
}

.wrap.my-booking-plugin h2 {
    font-size: 20px;
    margin-bottom: 10px;
    color: #333;
}

.wrap.my-booking-plugin label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: #555;
}

.wrap.my-booking-plugin input[type="text"],
.wrap.my-booking-plugin input[type="email"],
.wrap.my-booking-plugin input[type="datetime-local"],
.wrap.my-booking-plugin input[type="number"],
.wrap.my-booking-plugin select {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

.wrap.my-booking-plugin input[type="submit"],
.wrap.my-booking-plugin button {
    background-color: #0EBADC;
    color: #fff;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    border-radius: 5px;
    font-size: 16px;
    margin-right: 10px;
}

.wrap.my-booking-plugin input[type="submit"]:hover,
.wrap.my-booking-plugin button:hover {
    background-color: #0c9ab0;
}

.wrap.my-booking-plugin form {
    margin-bottom: 20px;
}

.wrap.my-booking-plugin ul {
    list-style: none;
    padding: 0;
}

.wrap.my-booking-plugin ul li {
    padding: 10px;
    border-bottom: 1px solid #ddd;
}

#modifyServiceModal,
#modifyEmployeeModal,
#modifyCustomerModal,
#modifyAppointmentModal,
#updateStatusModal {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 20px;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    z-index: 1000;
}

#modifyServiceModal h2,
#modifyEmployeeModal h2,
#modifyCustomerModal h2,
#modifyAppointmentModal h2,
#updateStatusModal h2 {
    margin-top: 0;
}
</style>';
}



function my_booking_employees_page() {
    global $wpdb;

    // Handle new employee addition
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_employee'])) {
        $wpdb->insert(
            "{$wpdb->prefix}my_booking_employees",
            array(
                'first_name' => sanitize_text_field($_POST['employee_first_name']),
                'last_name' => sanitize_text_field($_POST['employee_last_name']),
                'email' => sanitize_email($_POST['employee_email']),
                'department' => sanitize_text_field($_POST['employee_department'])
            )
        );
    }

    // Handle employee deletion
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_employee'])) {
        $employee_id = intval($_POST['employee_id']);
        $wpdb->delete("{$wpdb->prefix}my_booking_employees", array('id' => $employee_id));
    }

    // Handle employee modification
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['modify_employee'])) {
        $employee_id = intval($_POST['employee_id']);
        $wpdb->update(
            "{$wpdb->prefix}my_booking_employees",
            array(
                'first_name' => sanitize_text_field($_POST['employee_first_name']),
                'last_name' => sanitize_text_field($_POST['employee_last_name']),
                'email' => sanitize_email($_POST['employee_email']),
                'department' => sanitize_text_field($_POST['employee_department'])
            ),
            array('id' => $employee_id)
        );
    }

    $employees = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}my_booking_employees");

    echo '<div class="wrap my-booking-plugin"><h1>Employees</h1>';
    echo '<form method="POST"><h2>Add New Employee</h2>';
    echo '<label>First Name</label><input type="text" name="employee_first_name" required>';
    echo '<label>Last Name</label><input type="text" name="employee_last_name" required>';
    echo '<label>Email</label><input type="email" name="employee_email" required>';
    echo '<label>Department</label><input type="text" name="employee_department">';
    echo '<input type="submit" name="new_employee" value="Add Employee"></form>';

    echo '<h2>Existing Employees</h2><ul>';
    foreach ($employees as $employee) {
        echo '<li>';
        echo esc_html($employee->first_name) . ' ' . esc_html($employee->last_name) . ' - ' . esc_html($employee->email) . ' - ' . esc_html($employee->department);
        echo ' <form method="POST" style="display:inline;"><input type="hidden" name="employee_id" value="' . esc_attr($employee->id) . '">';
        echo '<input type="submit" name="delete_employee" value="Delete" onclick="return confirm(\'Are you sure you want to delete this employee?\');"></form>';
        echo ' <button onclick="modifyEmployee(' . esc_attr($employee->id) . ', \'' . esc_js($employee->first_name) . '\', \'' . esc_js($employee->last_name) . '\', \'' . esc_js($employee->email) . '\', \'' . esc_js($employee->department) . '\')">Modify</button>';
        echo '</li>';
    }
    echo '</ul></div>';

    // Modal for modifying employee
    echo '<div id="modifyEmployeeModal" style="display:none;">';
    echo '<form method="POST"><h2>Modify Employee</h2>';
    echo '<input type="hidden" name="employee_id" id="modify_employee_id">';
    echo '<label>First Name</label><input type="text" name="employee_first_name" id="modify_employee_first_name" required>';
    echo '<label>Last Name</label><input type="text" name="employee_last_name" id="modify_employee_last_name" required>';
    echo '<label>Email</label><input type="email" name="employee_email" id="modify_employee_email" required>';
    echo '<label>Department</label><input type="text" name="employee_department" id="modify_employee_department">';
    echo '<input type="submit" name="modify_employee" value="Modify Employee">';
    echo '</form></div>';

    ?>
    <script>
    function modifyEmployee(id, firstName, lastName, email, department) {
        document.getElementById('modify_employee_id').value = id;
        document.getElementById('modify_employee_first_name').value = firstName;
        document.getElementById('modify_employee_last_name').value = lastName;
        document.getElementById('modify_employee_email').value = email;
        document.getElementById('modify_employee_department').value = department;
        document.getElementById('modifyEmployeeModal').style.display = 'block';
    }
    </script>
    <?php

echo '<style>
.wrap.my-booking-plugin {
    width: 100%;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    background-color: #fff;
}

.wrap.my-booking-plugin h1 {
    font-size: 24px;
    margin-bottom: 20px;
    color: #0EBADC;
}

.wrap.my-booking-plugin h2 {
    font-size: 20px;
    margin-bottom: 10px;
    color: #333;
}

.wrap.my-booking-plugin label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: #555;
}

.wrap.my-booking-plugin input[type="text"],
.wrap.my-booking-plugin input[type="email"],
.wrap.my-booking-plugin input[type="datetime-local"],
.wrap.my-booking-plugin input[type="number"],
.wrap.my-booking-plugin select {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

.wrap.my-booking-plugin input[type="submit"],
.wrap.my-booking-plugin button {
    background-color: #0EBADC;
    color: #fff;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    border-radius: 5px;
    font-size: 16px;
    margin-right: 10px;
}

.wrap.my-booking-plugin input[type="submit"]:hover,
.wrap.my-booking-plugin button:hover {
    background-color: #0c9ab0;
}

.wrap.my-booking-plugin form {
    margin-bottom: 20px;
}

.wrap.my-booking-plugin ul {
    list-style: none;
    padding: 0;
}

.wrap.my-booking-plugin ul li {
    padding: 10px;
    border-bottom: 1px solid #ddd;
}

#modifyServiceModal,
#modifyEmployeeModal,
#modifyCustomerModal,
#modifyAppointmentModal,
#updateStatusModal {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 20px;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    z-index: 1000;
}

#modifyServiceModal h2,
#modifyEmployeeModal h2,
#modifyCustomerModal h2,
#modifyAppointmentModal h2,
#updateStatusModal h2 {
    margin-top: 0;
}
</style>';
}



function my_booking_customers_page() {
    global $wpdb;

    // Handle new customer addition
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_customer'])) {
        $wpdb->insert(
            "{$wpdb->prefix}my_booking_customers",
            array(
                'first_name' => sanitize_text_field($_POST['customer_first_name']),
                'last_name' => sanitize_text_field($_POST['customer_last_name']),
                'email' => sanitize_email($_POST['customer_email'])
            )
        );
    }

    // Handle customer deletion
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_customer'])) {
        $customer_id = intval($_POST['customer_id']);
        $wpdb->delete("{$wpdb->prefix}my_booking_customers", array('id' => $customer_id));
    }

    // Handle customer modification
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['modify_customer'])) {
        $customer_id = intval($_POST['customer_id']);
        $wpdb->update(
            "{$wpdb->prefix}my_booking_customers",
            array(
                'first_name' => sanitize_text_field($_POST['customer_first_name']),
                'last_name' => sanitize_text_field($_POST['customer_last_name']),
                'email' => sanitize_email($_POST['customer_email'])
            ),
            array('id' => $customer_id)
        );
    }

    $customers = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}my_booking_customers");

    echo '<div class="wrap my-booking-plugin"><h1>Customers</h1>';
    echo '<form method="POST"><h2>Add New Customer</h2>';
    echo '<label>First Name</label><input type="text" name="customer_first_name" required>';
    echo '<label>Last Name</label><input type="text" name="customer_last_name" required>';
    echo '<label>Email</label><input type="email" name="customer_email" required>';
    echo '<input type="submit" name="new_customer" value="Add Customer"></form>';

    echo '<h2>Existing Customers</h2><ul>';
    foreach ($customers as $customer) {
        echo '<li>';
        echo esc_html($customer->first_name) . ' ' . esc_html($customer->last_name) . ' - ' . esc_html($customer->email);
        echo ' <form method="POST" style="display:inline;"><input type="hidden" name="customer_id" value="' . esc_attr($customer->id) . '">';
        echo '<input type="submit" name="delete_customer" value="Delete" onclick="return confirm(\'Are you sure you want to delete this customer?\');"></form>';
        echo ' <button onclick="modifyCustomer(' . esc_attr($customer->id) . ', \'' . esc_js($customer->first_name) . '\', \'' . esc_js($customer->last_name) . '\', \'' . esc_js($customer->email) . '\')">Modify</button>';
        echo '</li>';
    }
    echo '</ul></div>';

    // Modal for modifying customer
    echo '<div id="modifyCustomerModal" style="display:none;">';
    echo '<form method="POST"><h2>Modify Customer</h2>';
    echo '<input type="hidden" name="customer_id" id="modify_customer_id">';
    echo '<label>First Name</label><input type="text" name="customer_first_name" id="modify_customer_first_name" required>';
    echo '<label>Last Name</label><input type="text" name="customer_last_name" id="modify_customer_last_name" required>';
    echo '<label>Email</label><input type="email" name="customer_email" id="modify_customer_email" required>';
    echo '<input type="submit" name="modify_customer" value="Modify Customer">';
    echo '</form></div>';

    ?>
    <script>
    function modifyCustomer(id, firstName, lastName, email) {
        document.getElementById('modify_customer_id').value = id;
        document.getElementById('modify_customer_first_name').value = firstName;
        document.getElementById('modify_customer_last_name').value = lastName;
        document.getElementById('modify_customer_email').value = email;
        document.getElementById('modifyCustomerModal').style.display = 'block';
    }
    </script>
    <?php

echo '<style>
.wrap.my-booking-plugin {
    width: 100%;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    background-color: #fff;
}

.wrap.my-booking-plugin h1 {
    font-size: 24px;
    margin-bottom: 20px;
    color: #0EBADC;
}

.wrap.my-booking-plugin h2 {
    font-size: 20px;
    margin-bottom: 10px;
    color: #333;
}

.wrap.my-booking-plugin label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: #555;
}

.wrap.my-booking-plugin input[type="text"],
.wrap.my-booking-plugin input[type="email"],
.wrap.my-booking-plugin input[type="datetime-local"],
.wrap.my-booking-plugin input[type="number"],
.wrap.my-booking-plugin select {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

.wrap.my-booking-plugin input[type="submit"],
.wrap.my-booking-plugin button {
    background-color: #0EBADC;
    color: #fff;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    border-radius: 5px;
    font-size: 16px;
    margin-right: 10px;
}

.wrap.my-booking-plugin input[type="submit"]:hover,
.wrap.my-booking-plugin button:hover {
    background-color: #0c9ab0;
}

.wrap.my-booking-plugin form {
    margin-bottom: 20px;
}

.wrap.my-booking-plugin ul {
    list-style: none;
    padding: 0;
}

.wrap.my-booking-plugin ul li {
    padding: 10px;
    border-bottom: 1px solid #ddd;
}

#modifyServiceModal,
#modifyEmployeeModal,
#modifyCustomerModal,
#modifyAppointmentModal,
#updateStatusModal {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 20px;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    z-index: 1000;
}

#modifyServiceModal h2,
#modifyEmployeeModal h2,
#modifyCustomerModal h2,
#modifyAppointmentModal h2,
#updateStatusModal h2 {
    margin-top: 0;
}
</style>';
}



function my_booking_appointments_page() {
    global $wpdb;

    // Handle new appointment addition
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_appointment'])) {
        $wpdb->insert(
            "{$wpdb->prefix}my_booking_appointments",
            array(
                'service_id' => intval($_POST['appointment_service']),
                'employee_id' => intval($_POST['appointment_employee']),
                'customer_id' => intval($_POST['appointment_customer']),
                'appointment_time' => sanitize_text_field($_POST['appointment_time']),
                'status' => 'pending'
            )
        );
    }

    // Handle appointment deletion
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_appointment'])) {
        $appointment_id = intval($_POST['appointment_id']);
        $wpdb->delete("{$wpdb->prefix}my_booking_appointments", array('id' => $appointment_id));
    }

    // Handle appointment modification
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['modify_appointment'])) {
        $appointment_id = intval($_POST['appointment_id']);
        $wpdb->update(
            "{$wpdb->prefix}my_booking_appointments",
            array(
                'service_id' => intval($_POST['appointment_service']),
                'employee_id' => intval($_POST['appointment_employee']),
                'customer_id' => intval($_POST['appointment_customer']),
                'appointment_time' => sanitize_text_field($_POST['appointment_time']),
                'status' => sanitize_text_field($_POST['appointment_status'])
            ),
            array('id' => $appointment_id)
        );
    }

    // Handle status update
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
        $appointment_id = intval($_POST['appointment_id']);
        $wpdb->update(
            "{$wpdb->prefix}my_booking_appointments",
            array('status' => sanitize_text_field($_POST['appointment_status'])),
            array('id' => $appointment_id)
        );
    }

    $appointments = $wpdb->get_results("SELECT a.*, c.email FROM {$wpdb->prefix}my_booking_appointments a JOIN {$wpdb->prefix}my_booking_customers c ON a.customer_id = c.id");
    $services = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}my_booking_services");
    $employees = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}my_booking_employees");
    $customers = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}my_booking_customers");

    echo '<div class="wrap my-booking-plugin"><h1>Appointments</h1>';
    echo '<form method="POST"><h2>Add New Appointment</h2>';
    echo '<label>Service</label><select name="appointment_service" required>';
    foreach ($services as $service) {
        echo '<option value="' . esc_attr($service->id) . '">' . esc_html($service->name) . '</option>';
    }
    echo '</select>';
    echo '<label>Employee</label><select name="appointment_employee" required>';
    foreach ($employees as $employee) {
        echo '<option value="' . esc_attr($employee->id) . '">' . esc_html($employee->first_name) . ' ' . esc_html($employee->last_name) . '</option>';
    }
    echo '</select>';
    echo '<label>Customer</label><select name="appointment_customer" required>';
    foreach ($customers as $customer) {
        echo '<option value="' . esc_attr($customer->id) . '">' . esc_html($customer->first_name) . ' ' . esc_html($customer->last_name) . '</option>';
    }
    echo '</select>';
    echo '<label>Appointment Time</label><input type="datetime-local" name="appointment_time" required>';
    echo '<input type="submit" name="new_appointment" value="Add Appointment"></form>';

    echo '<h2>Existing Appointments</h2><ul>';
    foreach ($appointments as $appointment) {
        $service = $wpdb->get_var($wpdb->prepare("SELECT name FROM {$wpdb->prefix}my_booking_services WHERE id = %d", $appointment->service_id));
        $employee = $wpdb->get_var($wpdb->prepare("SELECT CONCAT(first_name, ' ', last_name) FROM {$wpdb->prefix}my_booking_employees WHERE id = %d", $appointment->employee_id));
        $customer = $wpdb->get_var($wpdb->prepare("SELECT CONCAT(first_name, ' ', last_name) FROM {$wpdb->prefix}my_booking_customers WHERE id = %d", $appointment->customer_id));
        echo '<li>';
        echo esc_html($service) . ' with ' . esc_html($employee) . ' for ' . esc_html($customer) . ' (' . esc_html($appointment->email) . ') on ' . esc_html($appointment->appointment_time) . ' - Status: ' . esc_html($appointment->status);
        echo ' <form method="POST" style="display:inline;"><input type="hidden" name="appointment_id" value="' . esc_attr($appointment->id) . '">';
        echo '<input type="submit" name="delete_appointment" value="Delete" onclick="return confirm(\'Are you sure you want to delete this appointment?\');"></form>';
        echo ' <button onclick="modifyAppointment(' . esc_attr($appointment->id) . ', ' . esc_attr($appointment->service_id) . ', ' . esc_attr($appointment->employee_id) . ', ' . esc_attr($appointment->customer_id) . ', \'' . esc_js($appointment->appointment_time) . '\', \'' . esc_js($appointment->status) . '\')">Modify</button>';
        echo ' <button onclick="updateStatus(' . esc_attr($appointment->id) . ', \'' . esc_js($appointment->status) . '\')">Update Status</button>';
        echo '</li>';
    }
    echo '</ul></div>';

    // Modal for modifying appointment
    echo '<div id="modifyAppointmentModal" style="display:none;">';
    echo '<form method="POST"><h2>Modify Appointment</h2>';
    echo '<input type="hidden" name="appointment_id" id="modify_appointment_id">';
    echo '<label>Service</label><select name="appointment_service" id="modify_appointment_service" required>';
    foreach ($services as $service) {
        echo '<option value="' . esc_attr($service->id) . '">' . esc_html($service->name) . '</option>';
    }
    echo '</select>';
    echo '<label>Employee</label><select name="appointment_employee" id="modify_appointment_employee" required>';
    foreach ($employees as $employee) {
        echo '<option value="' . esc_attr($employee->id) . '">' . esc_html($employee->first_name) . ' ' . esc_html($employee->last_name) . '</option>';
    }
    echo '</select>';
    echo '<label>Customer</label><select name="appointment_customer" id="modify_appointment_customer" required>';
    foreach ($customers as $customer) {
        echo '<option value="' . esc_attr($customer->id) . '">' . esc_html($customer->first_name) . ' ' . esc_html($customer->last_name) . '</option>';
    }
    echo '</select>';
    echo '<label>Appointment Time</label><input type="datetime-local" name="appointment_time" id="modify_appointment_time" required>';
    echo '<label>Status</label><input type="text" name="appointment_status" id="modify_appointment_status" required>';
    echo '<input type="submit" name="modify_appointment" value="Modify Appointment">';
    echo '</form></div>';

    // Modal for updating status
    echo '<div id="updateStatusModal" style="display:none;">';
    echo '<form method="POST"><h2>Update Status</h2>';
    echo '<input type="hidden" name="appointment_id" id="update_status_id">';
    echo '<label>Status</label><input type="text" name="appointment_status" id="update_status_value" required>';
    echo '<input type="submit" name="update_status" value="Update Status">';
    echo '</form></div>';

    ?>
    <script>
    function modifyAppointment(id, serviceId, employeeId, customerId, appointmentTime, status) {
        document.getElementById('modify_appointment_id').value = id;
        document.getElementById('modify_appointment_service').value = serviceId;
        document.getElementById('modify_appointment_employee').value = employeeId;
        document.getElementById('modify_appointment_customer').value = customerId;
        document.getElementById('modify_appointment_time').value = appointmentTime;
        document.getElementById('modify_appointment_status').value = status;
        document.getElementById('modifyAppointmentModal').style.display = 'block';
    }

    function updateStatus(id, status) {
        document.getElementById('update_status_id').value = id;
        document.getElementById('update_status_value').value = status;
        document.getElementById('updateStatusModal').style.display = 'block';
    }
    </script>
    <?php

echo '<style>
.wrap.my-booking-plugin {
    width: 100%;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    background-color: #fff;
}

.wrap.my-booking-plugin h1 {
    font-size: 24px;
    margin-bottom: 20px;
    color: #0EBADC;
}

.wrap.my-booking-plugin h2 {
    font-size: 20px;
    margin-bottom: 10px;
    color: #333;
}

.wrap.my-booking-plugin label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: #555;
}

.wrap.my-booking-plugin input[type="text"],
.wrap.my-booking-plugin input[type="email"],
.wrap.my-booking-plugin input[type="datetime-local"],
.wrap.my-booking-plugin input[type="number"],
.wrap.my-booking-plugin select {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

.wrap.my-booking-plugin input[type="submit"],
.wrap.my-booking-plugin button {
    background-color: #0EBADC;
    color: #fff;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    border-radius: 5px;
    font-size: 16px;
    margin-right: 10px;
}

.wrap.my-booking-plugin input[type="submit"]:hover,
.wrap.my-booking-plugin button:hover {
    background-color: #0c9ab0;
}

.wrap.my-booking-plugin form {
    margin-bottom: 20px;
}

.wrap.my-booking-plugin ul {
    list-style: none;
    padding: 0;
}

.wrap.my-booking-plugin ul li {
    padding: 10px;
    border-bottom: 1px solid #ddd;
}

#modifyServiceModal,
#modifyEmployeeModal,
#modifyCustomerModal,
#modifyAppointmentModal,
#updateStatusModal {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 20px;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    z-index: 1000;
}

#modifyServiceModal h2,
#modifyEmployeeModal h2,
#modifyCustomerModal h2,
#modifyAppointmentModal h2,
#updateStatusModal h2 {
    margin-top: 0;
}
</style>';
}



function my_booking_notifications_page() {
    global $wpdb;
    $appointments = $wpdb->get_results("SELECT a.id, c.first_name, c.last_name, c.email, s.name AS service_name, e.first_name AS employee_first_name, e.last_name AS employee_last_name, a.appointment_time 
                                        FROM {$wpdb->prefix}my_booking_appointments a
                                        JOIN {$wpdb->prefix}my_booking_customers c ON a.customer_id = c.id
                                        JOIN {$wpdb->prefix}my_booking_services s ON a.service_id = s.id
                                        JOIN {$wpdb->prefix}my_booking_employees e ON a.employee_id = e.id");

    $templates = array(
        'approved' => 'Stimate domnule %client_numele_complet%,<br><br>
                       Ați programat cu succes programarea pentru %serviciu_numele% cu %angajat_numele_complet%. Vă așteptăm la adresa %locație_adresa% la %data_ora_încheierii%.<br><br>
                       Vă mulțumim că ați ales compania noastră,<br>
                       %numele_societății%.',
        'pending' => 'Stimate domnule %client_numele_complet%,<br><br>
                      Programarea pentru %serviciu_numele% cu %angajat_numele_complet% la %locație_adresa%, programată pentru %data_ora_încheierii%, așteaptă o confirmare.<br>
                      Vă mulțumim că ați ales compania noastră,<br>
                      %numele_societății%.',
        'rejected' => 'Stimate domnule %client_numele_complet%,<br><br>
                       Programarea dvs. pentru %serviciu_numele%, programată la %data_ora_încheierii% la %locație_adresa%, a fost respinsă.<br>
                       Vă mulțumim că ați ales compania noastră,<br>
                       %numele_societății%.',
        'canceled' => 'Stimate domnule %client_numele_complet%,<br><br>
                       Programarea dvs. pentru %serviciu_numele%, programată la %data_ora_încheierii% la %locație_adresa%, a fost anulată.<br>
                       Vă mulțumim că ați ales compania noastră,<br>
                       %numele_societății%.',
        'rescheduled' => 'Stimate domnule %client_numele_complet%,<br><br>
                          Programarea dumneavoastră pentru %serviciu_numele% cu %angajat_numele_complet% a fost restabilită. Noua dată și oră este %data_ora_încheierii%. Vă așteptăm la adresa %locație_adresa%.<br><br>
                          Vă mulțumim că ați ales compania noastră,<br>
                          %numele_societății%.'
    );

    echo '<div class="wrap my-booking-plugin"><h1>Notifications</h1>';
    echo '<form method="POST" id="notificationForm"><h2>Select Appointment</h2>';
    echo '<label>Appointment</label><select name="appointment_id" id="appointment_id" required>';
    foreach ($appointments as $appointment) {
        echo '<option value="' . esc_attr($appointment->id) . '" data-email="' . esc_attr($appointment->email) . '" data-customer="' . esc_attr($appointment->first_name . ' ' . $appointment->last_name) . '" data-service="' . esc_attr($appointment->service_name) . '" data-employee="' . esc_attr($appointment->employee_first_name . ' ' . $appointment->employee_last_name) . '" data-time="' . esc_attr($appointment->appointment_time) . '">' . esc_html($appointment->first_name . ' ' . $appointment->last_name . ' (' . $appointment->email . ') - ' . $appointment->service_name . ' - ' . $appointment->appointment_time) . '</option>';
    }
    echo '</select>';
    echo '<br><br><label>Template</label><select name="notification_template" id="notification_template" required>';
    foreach ($templates as $key => $template) {
        echo '<option value="' . esc_attr($key) . '">' . ucfirst($key) . '</option>';
    }
    echo '</select>';
    echo '</form>';
    echo '<div id="templateContainer" style="display:none;">';
    foreach ($templates as $key => $template) {
        echo '<div id="template-' . esc_attr($key) . '" class="template-content" style="display:none;">';
        echo '<p>' . $template . '</p>';
        echo '<form id="sendEmailForm-' . esc_attr($key) . '" method="POST" action="" target="_blank">';
        echo '<input type="submit" value="Send">';
        echo '</form>';
        echo '</div>';
    }
    echo '</div>';
    echo '</div>';

    ?>
    <script>
    jQuery(document).ready(function($) {
        $('#notification_template').on('change', function() {
            var selectedTemplate = $(this).val();
            $('.template-content').hide();
            $('#template-' + selectedTemplate).show();
            $('#templateContainer').show();
        });

        $('form[id^="sendEmailForm"]').on('submit', function(e) {
            e.preventDefault();
            var selectedAppointment = $('#appointment_id').find(':selected');
            var email = selectedAppointment.data('email');
            var customerName = selectedAppointment.data('customer');
            var serviceName = selectedAppointment.data('service');
            var employeeName = selectedAppointment.data('employee');
            var appointmentTime = selectedAppointment.data('time');
            var appointmentId = selectedAppointment.val();

            var selectedTemplate = $('#notification_template').val();
            var templateContent = $('#template-' + selectedTemplate).find('p').html();

            // Inlocuirea variabilelor din template cu valorile reale
            templateContent = templateContent.replace('%client_numele_complet%', customerName);
            templateContent = templateContent.replace('%serviciu_numele%', serviceName);
            templateContent = templateContent.replace('%angajat_numele_complet%', employeeName);
            templateContent = templateContent.replace('%data_ora_încheierii%', appointmentTime);
            templateContent = templateContent.replace('%numele_societății%', '<?php echo get_bloginfo('name'); ?>');

            // %locație_adresa% va rămâne nemodificat
            var mailtoLink = 'https://mail.google.com/mail/?view=cm&fs=1&to=' + encodeURIComponent(email) + '&su=Appointment Notification&body=' + encodeURIComponent(templateContent);

            // Actualizarea statusului programării
            $.post(ajaxurl, {
                action: 'update_appointment_status',
                appointment_id: appointmentId,
                status: selectedTemplate
            }, function(response) {
                if (response.success) {
                    window.open(mailtoLink, '_blank');
                } else {
                    alert('Failed to update appointment status.');
                }
            });
        });
    });
    </script>
    <?php

echo '<style>
.wrap.my-booking-plugin {
    width: 100%;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    background-color: #fff;
}

.wrap.my-booking-plugin h1 {
    font-size: 24px;
    margin-bottom: 20px;
    color: #0EBADC;
}

.wrap.my-booking-plugin h2 {
    font-size: 20px;
    margin-bottom: 10px;
    color: #333;
}

.wrap.my-booking-plugin label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    color: #555;
}

.wrap.my-booking-plugin input[type="text"],
.wrap.my-booking-plugin input[type="email"],
.wrap.my-booking-plugin input[type="datetime-local"],
.wrap.my-booking-plugin input[type="number"],
.wrap.my-booking-plugin select {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

.wrap.my-booking-plugin input[type="submit"],
.wrap.my-booking-plugin button {
    background-color: #0EBADC;
    color: #fff;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    border-radius: 5px;
    font-size: 16px;
    margin-right: 10px;
}

.wrap.my-booking-plugin input[type="submit"]:hover,
.wrap.my-booking-plugin button:hover {
    background-color: #0c9ab0;
}

.wrap.my-booking-plugin form {
    margin-bottom: 20px;
}

.wrap.my-booking-plugin ul {
    list-style: none;
    padding: 0;
}

.wrap.my-booking-plugin ul li {
    padding: 10px;
    border-bottom: 1px solid #ddd;
}

#modifyServiceModal,
#modifyEmployeeModal,
#modifyCustomerModal,
#modifyAppointmentModal,
#updateStatusModal {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 20px;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    z-index: 1000;
}

#modifyServiceModal h2,
#modifyEmployeeModal h2,
#modifyCustomerModal h2,
#modifyAppointmentModal h2,
#updateStatusModal h2 {
    margin-top: 0;
}
</style>';
}



// Functie pentru actualizarea statusului programarii
add_action('wp_ajax_update_appointment_status', 'update_appointment_status');
function update_appointment_status() {
    global $wpdb;
    $appointment_id = intval($_POST['appointment_id']);
    $status = sanitize_text_field($_POST['status']);

    $updated = $wpdb->update(
        "{$wpdb->prefix}my_booking_appointments",
        array('status' => $status),
        array('id' => $appointment_id),
        array('%s'),
        array('%d')
    );

    if ($updated !== false) {
        wp_send_json_success();
    } else {
        wp_send_json_error();
    }
}

function my_booking_settings_page() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
        update_option('my_booking_default_time_slot', intval($_POST['default_time_slot']));
        update_option('my_booking_sender_name', sanitize_text_field($_POST['sender_name']));
        update_option('my_booking_sender_email', sanitize_email($_POST['sender_email']));
        update_option('my_booking_time_zone', sanitize_text_field($_POST['time_zone']));
    }

    $default_time_slot = get_option('my_booking_default_time_slot', 30);
    $sender_name = get_option('my_booking_sender_name', get_bloginfo('name'));
    $sender_email = get_option('my_booking_sender_email', get_bloginfo('admin_email'));
    $time_zone = get_option('my_booking_time_zone', 'UTC');

    $time_zones = timezone_identifiers_list();

    echo '<div class="wrap my-booking-plugin"><h1>Settings</h1>';
    echo '<form method="POST"><h2>General Settings</h2>';
    echo '<label>Business Name</label><input type="text" name="sender_name" value="' . esc_attr($sender_name) . '">';
    echo '<label>Business Email</label><input type="email" name="sender_email" value="' . esc_attr($sender_email) . '">';
    echo '<label>Time Zone</label><select name="time_zone">';
    foreach ($time_zones as $zone) {
        echo '<option value="' . esc_attr($zone) . '"' . selected($time_zone, $zone, false) . '>' . esc_html($zone) . '</option>';
    }
    echo '</select>';
    echo '<h2>Booking Settings</h2>';
    echo '<label>Booking Time Slot (minutes)</label><input type="number" name="default_time_slot" value="' . esc_attr($default_time_slot) . '">';
    echo '<input type="submit" name="save_settings" value="Save Settings"></form></div>';

    echo '<style>
        .wrap.my-booking-plugin {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        .wrap.my-booking-plugin h1 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #0EBADC;
        }

        .wrap.my-booking-plugin h2 {
            font-size: 20px;
            margin-bottom: 10px;
            color: #333;
        }

        .wrap.my-booking-plugin label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        .wrap.my-booking-plugin input[type="text"],
        .wrap.my-booking-plugin input[type="email"],
        .wrap.my-booking-plugin input[type="datetime-local"],
        .wrap.my-booking-plugin input[type="number"],
        .wrap.my-booking-plugin select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .wrap.my-booking-plugin input[type="submit"],
        .wrap.my-booking-plugin button {
            background-color: #0EBADC;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            margin-right: 10px;
        }

        .wrap.my-booking-plugin input[type="submit"]:hover,
        .wrap.my-booking-plugin button:hover {
            background-color: #0c9ab0;
        }

        .wrap.my-booking-plugin form {
            margin-bottom: 20px;
        }

        .wrap.my-booking-plugin ul {
            list-style: none;
            padding: 0;
        }

        .wrap.my-booking-plugin ul li {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        #modifyServiceModal,
        #modifyEmployeeModal,
        #modifyCustomerModal,
        #modifyAppointmentModal,
        #updateStatusModal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        #modifyServiceModal h2,
        #modifyEmployeeModal h2,
        #modifyCustomerModal h2,
        #modifyAppointmentModal h2,
        #updateStatusModal h2 {
            margin-top: 0;
        }
    </style>';
}

function my_booking_render_booking_form() {
    ob_start();
    ?>
    <style>
        #my-booking-form {
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 20px; /* Border radius increased */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        #my-booking-form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        #my-booking-form input[type="text"],
        #my-booking-form input[type="email"],
        #my-booking-form input[type="datetime-local"],
        #my-booking-form select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        #my-booking-form input[type="submit"] {
            background-color: #0EBADC; /* Button color */
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
        }

        #my-booking-form input[type="submit"]:hover {
            background-color: #0c9ab0;
        }

        #email-error {
            color: red;
            display: none;
        }


        .ui-datepicker {
            width: 100%; /* Full width calendar */
        }

        .ui-datepicker table {
            width: 100%;
        }

        .ui-datepicker-header {
            background: #0EBADC; /* Background color */
            color: #fff;
        }
        

    </style>

<div id="my-booking-form">
        <form method="post" id="bookingForm">
            <h3>Select Appointment Date</h3>
            <div id="calendar"></div>
            <input type="hidden" name="appointment_date" id="appointment_date" required>

            <h3>Select Appointment Time</h3>
            <label for="appointment_time">Time</label>
            <select name="appointment_time" id="appointment_time" required>
                <?php
                $start_time = strtotime('08:00');
                $end_time = strtotime('16:00');
                for ($i = $start_time; $i <= $end_time; $i += 1800) {
                    echo '<option value="' . date('H:i', $i) . '">' . date('H:i', $i) . '</option>';
                }
                ?>
            </select>

            <h3>Customer Information</h3>
            <label for="customer_first_name">First Name</label>
            <input type="text" name="customer_first_name" id="customer_first_name" required>

            <label for="customer_last_name">Last Name</label>
            <input type="text" name="customer_last_name" id="customer_last_name" required>

            <label for="customer_email">Email</label>
            <input type="text" name="customer_email" id="customer_email" required>
            <div id="email-error">Please enter a valid email address.</div>

            <h3>Appointment Details</h3>
            <label for="service">Service</label>
            <select name="service" id="service" required>
                <?php
                global $wpdb;
                $services = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}my_booking_services");
                foreach ($services as $service) {
                    echo '<option value="' . esc_attr($service->id) . '">' . esc_html($service->name) . '</option>';
                }
                ?>
            </select>

            <label for="employee">Employee</label>
            <select name="employee" id="employee" required>
                <?php
                $employees = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}my_booking_employees");
                foreach ($employees as $employee) {
                    echo '<option value="' . esc_attr($employee->id) . '">' . esc_html($employee->first_name) . ' ' . esc_html($employee->last_name) . ' - ' . esc_html($employee->department) . '</option>';
                }
                ?>
            </select>

            <input type="submit" value="Book Appointment">
        </form>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('my_booking_form', 'my_booking_render_booking_form');


// Add AJAX action to get booked times
add_action('wp_ajax_my_booking_get_unavailable_times', 'my_booking_get_unavailable_times');
add_action('wp_ajax_nopriv_my_booking_get_unavailable_times', 'my_booking_get_unavailable_times');

function my_booking_get_unavailable_times() {
    global $wpdb;

    $date = sanitize_text_field($_POST['date']);
    $service_id = intval($_POST['service']);
    $employee_id = intval($_POST['employee']);
    $appointments = $wpdb->get_results($wpdb->prepare(
        "SELECT appointment_time FROM {$wpdb->prefix}my_booking_appointments WHERE DATE(appointment_time) = %s AND service_id = %d AND employee_id = %d",
        $date, $service_id, $employee_id
    ));

    $unavailable_times = [];
    foreach ($appointments as $appointment) {
        $unavailable_times[] = date('H:i', strtotime($appointment->appointment_time));
    }

    wp_send_json_success($unavailable_times);
}


add_action('wp_ajax_my_booking_save_appointment', 'my_booking_save_appointment');
add_action('wp_ajax_nopriv_my_booking_save_appointment', 'my_booking_save_appointment');

function my_booking_save_appointment() {
    global $wpdb;

    // Validate and sanitize input data
    $customer_first_name = sanitize_text_field($_POST['customer_first_name']);
    $customer_last_name = sanitize_text_field($_POST['customer_last_name']);
    $customer_email = sanitize_email($_POST['customer_email']);
    $service_id = intval($_POST['service']);
    $employee_id = intval($_POST['employee']);
    $appointment_date = sanitize_text_field($_POST['appointment_date']);
    $appointment_time = sanitize_text_field($_POST['appointment_time']);
    $appointment_datetime = $appointment_date . ' ' . $appointment_time;

    // Check if appointment already exists
    $existing_appointment = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}my_booking_appointments WHERE appointment_time = %s AND service_id = %d AND employee_id = %d",
        $appointment_datetime, $service_id, $employee_id
    ));

    if ($existing_appointment > 0) {
        wp_send_json_error(['message' => 'An appointment already exists at this date and time.']);
    } else {
        // Insert new customer
        $wpdb->insert(
            "{$wpdb->prefix}my_booking_customers",
            array(
                'first_name' => $customer_first_name,
                'last_name' => $customer_last_name,
                'email' => $customer_email
            )
        );
        $customer_id = $wpdb->insert_id;

        // Insert new appointment
        $wpdb->insert(
            "{$wpdb->prefix}my_booking_appointments",
            array(
                'service_id' => $service_id,
                'employee_id' => $employee_id,
                'customer_id' => $customer_id,
                'appointment_time' => $appointment_datetime,
                'status' => 'pending'
            )
        );

        wp_send_json_success();
    }
}



?>