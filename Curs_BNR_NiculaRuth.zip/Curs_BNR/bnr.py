from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import time

driver = webdriver.Chrome()
driver.get("https://www.cursbnr.ro/convertor-valutar")

time.sleep(5)

# Seteaza data: ziua 34 din an => 03/02/2025
data_input = driver.find_element(By.ID, "data_valuta")
driver.execute_script("arguments[0].value = '03/02/2025'", data_input)

# Seteaza suma
suma_input = driver.find_element(By.ID, "initial-value")
suma_input.clear()
suma_input.send_keys("1000")

#  Selecteaza HKD 
valuta_from = Select(driver.find_element(By.ID, "from-currency"))
valuta_from.select_by_visible_text("HKD")

# (opțional) se poate selecta si RON ca valuta tinta
# valuta_to = Select(driver.find_element(By.ID, "to-currency"))
# valuta_to.select_by_visible_text("RON")

# Asteapta ca JavaScript-ul sa actualizeze rezultatul
time.sleep(2)

# Gaseste inputul de rezultat pe baza etichetei "REZULTAT"
rezultat_input = driver.find_element(By.XPATH, "//label[contains(text(), 'REZULTAT')]/following::input[1]")
rezultat = rezultat_input.get_attribute("value")

# Opreste inchidere automata
input("\n🔵 Apasă Enter pentru a închide browserul...")

driver.quit()