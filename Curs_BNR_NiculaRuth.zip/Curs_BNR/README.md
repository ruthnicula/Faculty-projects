# Convertor Valutar Automatizat - Selenium

Acest proiect automatizeaza completarea formularului de pe [cursbnr.ro](https://www.cursbnr.ro/convertor-valutar) folosind Python si Selenium.

## Ce face scriptul:
- Deschide pagina convertorului valutar BNR
- Seteaza automat:
  - Data: **03/02/2025** (ziua 34 din an deoarece sunt nr 34 din catalog)
  - Suma: **1000**
  - Valuta: **HKD** (dolar Hong Kong)
- Asteapta actualizarea rezultatului
- Citeste si afiseaza in terminal valoarea convertita in **RON**
- Mentine browserul deschis pana se apasa Enter

## Cerinte
- Python 3.8+
- Google Chrome instalat
- ChromeDriver compatibil (adaugat in PATH)


## Rulare 
streamlit run bnr.py

## Instalare pachete

Instaleaza Selenium cu pip:
```bash
pip install selenium

