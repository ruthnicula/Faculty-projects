# prognoza schimb valutar ron - hkd

acest script python:

1. extrage cursul actual al dolarului din hong kong (hkd) fata de ron de pe site-ul oficial bnr
2. colecteaza date istorice ale cursului hkd din 2005 pana in prezent
3. prelucreaza datele pentru a obtine o serie zilnica completa, fara intreruperi
4. aplica un model prophet pentru a realiza o prognoza a cursului valutar pentru ziua urmatoare
5. afiseaza rezultatele in consola

---

## cerinte

instaleaza urmatoarele pachete python:

```bash
pip install requests beautifulsoup4 pandas prophet
