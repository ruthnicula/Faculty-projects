import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime, timedelta
from prophet import Prophet

# 1. cursul hkd din ziua curenta
def extrage_curs_hkd_azi():
    url = "https://www.cursbnr.ro/curs-bnr-azi"
    headers = {"User-Agent": "Mozilla/5.0"}
    try:
        response = requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.text, "html.parser")
        rows = soup.find("table", class_="table").find_all("tr")
        for row in rows:
            cols = row.find_all("td")
            if len(cols) >= 3 and cols[0].text.strip() == "HKD":
                return float(cols[2].text.strip().replace(",", "."))
    except Exception as e:
        print(f"[eroare curs azi]: {e}")
    return None

# 2. seria istorica hkd (2005 pana azi)
def extrage_istoric_hkd():
    url = "https://www.cursbnr.ro/curs-valutar-bnr"
    headers = {"User-Agent": "Mozilla/5.0"}

    data = {
        "currency": "HKD",
        "dataStart": "01/01/2005",
        "data": datetime.today().strftime("%d/%m/%Y"),
        "butsub": "Afiseaza"
    }

    try:
        response = requests.post(url, data=data, headers=headers, timeout=15)
        soup = BeautifulSoup(response.text, "html.parser")
        tabel = soup.find("table", {"id": "table-currencies"})
        if not tabel:
            print("tabelul cu istoric nu a fost gasit")
            return pd.DataFrame()

        rows = tabel.find_all("tr")[1:]
        records = []
        for row in rows:
            cols = row.find_all("td")
            if len(cols) >= 2:
                try:
                    data_curs = datetime.strptime(cols[0].text.strip(), "%d.%m.%Y")
                    valoare = float(cols[1].text.strip().replace(",", "."))
                    records.append({"ds": data_curs, "y": valoare})
                except:
                    continue
        return pd.DataFrame(records)
    except Exception as e:
        print(f"[eroare extragere istoric]: {e}")
        return pd.DataFrame()

# 3. forecast pentru ziua urmatoare
def face_forecast(df):
    df = df.sort_values("ds")
    df.set_index("ds", inplace=True)
    df = df.asfreq("D")
    df["y"] = df["y"].interpolate(method="linear").bfill()
    df.reset_index(inplace=True)

    model = Prophet(daily_seasonality=True)
    model.fit(df)

    future = model.make_future_dataframe(periods=1)
    forecast = model.predict(future)

    yhat = forecast.tail(1)["yhat"].values[0]
    return round(yhat, 4)

# 4. executa tot
curs_azi = extrage_curs_hkd_azi()
df_istoric = extrage_istoric_hkd()

if curs_azi and not df_istoric.empty:
    predictie = face_forecast(df_istoric)
    print(f"cursul hkd azi ({datetime.today().date()}): {curs_azi}")
    print(f"prognoza schimb valutar ron - hkd pentru {datetime.today().date() + timedelta(days=1)}: {predictie}")
else:
    print("nu s-au putut extrage datele.")
