from smolagents import CodeAgent,  tool

import yaml
import os
from tools.final_answer import FinalAnswerTool
import StreamlitUI
from smolagents import LiteLLMModel



# @tool
# def save_file(file_path: str, content: str) -> str:
#     """A tool that saves a file at the specified path with the given content.
#     Args:
#         file_path: The full path where the file should be saved.
#         content: The text content to write into the file.
#     """
#     try:
#         os.makedirs(os.path.dirname(file_path), exist_ok=True)
#         with open(file_path, "w", encoding="utf-8") as file:
#             file.write(content)
#         return f"File saved successfully at {file_path}"
#     except Exception as e:
#         return f"Error saving file: {str(e)}"

@tool
def get_name_meaning(name: str) -> str:
    """
    A simple tool that returns the meaning of a given name.

    Args:
        name: The name for which the meaning is to be found.

    Returns:
        A string describing the meaning of the name.
    """
    name_meanings = {
        "Andrei": "Nume de origine greacă, înseamnă 'bărbat' sau 'curajos'.",
        "Maria": "Derivat din numele ebraic Miriam, înseamnă 'marea sau amărăciunea', dar și 'doamnă', 'regină'.",
        "Ion": "De origine ebraică, înseamnă 'darul lui Dumnezeu'.",
        "Elena": "Derivat din grecescul 'Helene', înseamnă 'lumina' sau 'strălucirea'."
    }
    return name_meanings.get(name, "Nu am găsit semnificația pentru acest nume.")

# model = HfApiModel(
#     max_tokens=2096,
#     temperature=0.5,
#     model_id='google/gemma-3-4b-it', #'Qwen/Qwen2.5-32B-Instruct', #'https://pflgm2locj2t89co.us-east-1.aws.endpoints.huggingface.cloud',
#     custom_role_conversions=None,
#     token = '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'
# )

# Now initialize tools
final_answer = FinalAnswerTool()


model = LiteLLMModel(
  model_id= 'ollama/smallthinker:latest',
  base_url='http://localhost:11434',  
  max_tokens=2048,
  temperature=0.5
)

with open("prompts.yaml", 'r') as stream:
    prompt_templates = yaml.safe_load(stream)
    
agent = CodeAgent(
    model=model,
    # tools=[final_answer, save_file],
    tools = [final_answer,get_name_meaning],
    max_steps=4,
    planning_interval=None,
    description=None,
    prompt_templates=prompt_templates
)

print("Hello, Streamlit is running! with smallthinker.")  # Minimal test
StreamlitUI.launch(agent)
