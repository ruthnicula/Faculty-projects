import streamlit as st
from smolagents.agent_types import AgentAudio, AgentImage, AgentText, handle_agent_output_types
from smolagents.agents import ActionStep, MultiStepAgent
from smolagents.memory import MemoryStep
from smolagents.utils import _is_package_available
from typing import Optional

def pull_messages_from_step(step_log: MemoryStep):
    """Extract messages from agent steps for Streamlit display."""
    if isinstance(step_log, ActionStep):
        step_number = f"Step {step_log.step_number}" if step_log.step_number is not None else ""
        st.write(f"**{step_number}**")
        
        if hasattr(step_log, "model_output") and step_log.model_output:
            model_output = step_log.model_output.strip().replace("```<end_code>", "```")
            st.write(model_output)
        
        if hasattr(step_log, "tool_calls") and step_log.tool_calls:
            first_tool_call = step_log.tool_calls[0]
            content = str(first_tool_call.arguments).strip() if isinstance(first_tool_call.arguments, dict) else str(first_tool_call.arguments)
            st.write(f"🛠️ Used tool: {first_tool_call.name}\n\n{content}")
        
        if hasattr(step_log, "observations") and step_log.observations:
            st.write(f"📝 Execution Logs:\n\n{step_log.observations.strip()}")
        
        if hasattr(step_log, "error") and step_log.error:
            st.error(f"💥 Error: {step_log.error}")

def stream_to_streamlit(agent, task: str, reset_agent_memory: bool = False, additional_args: Optional[dict] = None):
    """Runs an agent with a task and displays messages in Streamlit."""
    try:
        st.write("**Running agent...**")
        st.write(f"**Task:**\n{task}")
        for step_log in agent.run(task, stream=True, reset=reset_agent_memory, additional_args=additional_args):
            
            if hasattr(step_log, "model_output"):
                print("Raw model output:", step_log.model_output)
            else:
                print("Raw model output:", step_log)
            st.write("**Agent Step Log:**")
            pull_messages_from_step(step_log)
            
            final_answer = handle_agent_output_types(step_log)
            st.write("**Final Answer:**")
            if final_answer:
                if isinstance(final_answer, AgentText):
                    st.write(f"**Final answer:**\n{final_answer.to_string()}")
                elif isinstance(final_answer, AgentImage):
                    st.image(final_answer.to_string())
                elif isinstance(final_answer, AgentAudio):
                    st.audio(final_answer.to_string())
            else:
                st.write("No final answer found.")
            if final_answer:
                if isinstance(final_answer, AgentText):
                    st.write(f"**Final answer:**\n{final_answer.to_string()}")
                elif isinstance(final_answer, AgentImage):
                    st.image(final_answer.to_string())
                elif isinstance(final_answer, AgentAudio):
                    st.audio(final_answer.to_string())
            else:
                st.write("No final answer found.")
    except Exception as e:
        st.error(f"Error running agent: {str(e)}")

def main(agent):
    """Streamlit app entry point."""
    DEBUG_MODE = False  # Toggle this

    st.title("AI Agent Chat")

    if DEBUG_MODE:
        user_input = "Tell me a joke"
        stream_to_streamlit(agent, user_input)
        st.stop()  # Prevent Streamlit from rerunning the page
    else:
        user_input = st.text_input("Enter your query:")
    
        if st.button("Submit"):
            if not user_input.strip():
                st.warning("Please enter a query before submitting.")
            else:
                print('Taking input to agents')
                stream_to_streamlit(agent, user_input)
        

def launch(agent):
    #agent = MultiStepAgent()  # Ensure this is correctly initialized in your project
    main(agent)
